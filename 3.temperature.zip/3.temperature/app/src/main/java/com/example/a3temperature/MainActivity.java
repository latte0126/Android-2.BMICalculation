package com.example.a3temperature;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity<view> extends AppCompatActivity {


    boolean isChanged = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void Conversion_button(View view) {
        Button Conversion = (Button) findViewById(R.id.button);
        EditText input = (EditText) findViewById(R.id.editTextTextPersonName);
        TextView temperature = (TextView) findViewById(R.id.Textview1);
        TextView output = (TextView) findViewById(R.id.textView);
        TextView input1 = (TextView) findViewById(R.id.textView2);
        DecimalFormat nf = new DecimalFormat("0.00");
        if (isChanged){
            Conversion.setText("Conversion");
            temperature.setText("temperature(Fahrenheit)");
            double C = Double.parseDouble(input.getText().toString());
            double F = (C*1.8)+32;
            output.setText(nf.format(F)+"°F");
            input1.setText(input.getText()+"°C");

        }
        else{
            Conversion.setText("Conversion");
            temperature.setText("temperature(Celsius)");
            double F = Double.parseDouble(input.getText().toString());
            double C = (F-32)/1.8;
            output.setText(nf.format(C)+"°C");
            input1.setText(input.getText()+"°F");


        }
        input.setText("");
        isChanged=!isChanged;
    }
}